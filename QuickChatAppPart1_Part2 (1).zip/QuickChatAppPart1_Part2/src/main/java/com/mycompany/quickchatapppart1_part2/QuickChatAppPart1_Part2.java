/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapppart1_part2;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class QuickChatAppPart1_Part2 {

  


    static ArrayList<Message> messages = new ArrayList<>();

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Register - Enter a username (must contain _ and be ≤ 5 characters):");
        if (!isValidUsername(username)) {
            showError("Invalid username. It must contain an underscore and be 5 characters or fewer.");
            return;
        }

        String password = JOptionPane.showInputDialog("Register - Enter a password (min 8 chars, 1 uppercase, 1 number, 1 special char):");
        if (!isValidPassword(password)) {
            showError("Invalid password. It must be at least 8 characters, include 1 uppercase letter, 1 number, and 1 special character.");
            return;
        }

        String cellphone = JOptionPane.showInputDialog("Register - Enter your SA phone number (e.g. +27831234567):");
        if (!isValidCellphone(cellphone)) {
            showError("Invalid cellphone number. Must start with +27 and be 12 digits total.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");

        // === Login ===
        String loginUsername = JOptionPane.showInputDialog("Login - Enter your username:");
        String loginPassword = JOptionPane.showInputDialog("Login - Enter your password:");

        if (!username.equals(loginUsername) || !password.equals(loginPassword)) {
            showError("Login failed. Incorrect username or password.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Login successful. Welcome to QuickChat, " + username + "!");

        boolean running = true;
        while (running) {
            String[] options = {"Send Message", "Show Messages", "Update Status", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Select an option:", "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0: // Send Message
                    String countStr = JOptionPane.showInputDialog("How many messages would you like to send?");
                    int count = Integer.parseInt(countStr);
                    for (int i = 1; i <= count; i++) {
                        String msg = JOptionPane.showInputDialog("Enter message " + i + ":");
                        messages.add (new Message(msg));
                        JOptionPane.showMessageDialog(null, "Message " + i + " sent.");
                    }
                    break;

                case 1: // Show Messages
                    if (messages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent.");
                    } else {
                        StringBuilder msgList = new StringBuilder("Messages:\n");
                        for (int i = 0; i < messages.size(); i++) {
                            msgList.append((i + 1)).append(". ").append(messages.get(i)).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, msgList.toString());
                    }
                    break;

                case 2: // Update Status
                    if (messages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages to update.");
                        break;
                    }

                    StringBuilder msgChoices = new StringBuilder();
                    for (int i = 0; i < messages.size(); i++) {
                        msgChoices.append((i + 1)).append(". ").append(messages.get(i)).append("\n");
                    }

                    String indexStr = JOptionPane.showInputDialog("Select message to update:\n" + msgChoices);
                    int msgIndex = Integer.parseInt(indexStr) - 1;

                    if (msgIndex >= 0 && msgIndex < messages.size()) {
                        String[] statuses = {"Delivered", "Read"};
                        int status = JOptionPane.showOptionDialog(null, "Select new status:", "Update Message Status",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, statuses, statuses[0]);

                        if (status == 0) messages.get(msgIndex).setStatus("Delivered");
                        else if (status == 1) messages.get(msgIndex).setStatus("Read");

                        JOptionPane.showMessageDialog(null, "Message status updated.");
                    } else {
                        showError("Invalid message number.");
                    }
                    break;

                case 3: // Quit
                    running = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    break;

                default:
                    running = false;
                    break;
            }
        }
    }

    // === Validation Methods ===
    public static boolean isValidUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.matches("(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}");
    }

    public static boolean isValidCellphone(String number) {
        return number != null && number.matches("\\+27\\d{9}");
    }

    private static void showError(String msg) {
        JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// === Message Class ===
class Message {
    private String content;
    private String status;

    public Message(String content) {
        this.content = content;
        this.status = "Sent";
    }

    public void setStatus(String newStatus) {
        this.status = newStatus;
    }

    @Override
    public String toString() {
        return "\"" + content + "\" [" + status + "]";
    }
}

    
